if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'app'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'app'.");
}
var app = function (_, Kotlin) {
  'use strict';
  var Unit = Kotlin.kotlin.Unit;
  var ArrayList_init = Kotlin.kotlin.collections.ArrayList_init_ww73n8$;
  var to = Kotlin.kotlin.to_ujzrz7$;
  var hashMapOf = Kotlin.kotlin.collections.hashMapOf_qfcya0$;
  var toString = Kotlin.toString;
  var throwCCE = Kotlin.throwCCE;
  var json = Kotlin.kotlin.js.json_pyyo18$;
  var indexOf = Kotlin.kotlin.collections.indexOf_mjy6jw$;
  var kotlin = Kotlin.kotlin;
  var equals = Kotlin.equals;
  var toInt = Kotlin.kotlin.text.toInt_pdl1vz$;
  var first = Kotlin.kotlin.collections.first_us0mfu$;
  var toList = Kotlin.kotlin.collections.toList_abgq59$;
  var toMap = Kotlin.kotlin.collections.toMap_6hr0sd$;
  var Kind_OBJECT = Kotlin.Kind.OBJECT;
  var Kind_INTERFACE = Kotlin.Kind.INTERFACE;
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var String_0 = String;
  var contains = Kotlin.kotlin.text.contains_li3zpu$;
  var asList = Kotlin.org.w3c.dom.asList_kt9thq$;
  var ensureNotNull = Kotlin.ensureNotNull;
  var addClass = Kotlin.kotlin.dom.addClass_hhb33f$;
  var splitToSequence = Kotlin.kotlin.text.splitToSequence_ip8yn$;
  var removeClass = Kotlin.kotlin.dom.removeClass_hhb33f$;
  var Regex_init = Kotlin.kotlin.text.Regex_init_61zpoe$;
  var replace = Kotlin.kotlin.text.replace_680rmw$;
  var capitalize = Kotlin.kotlin.text.capitalize_pdl1vz$;
  var trim = Kotlin.kotlin.text.trim_wqw3xr$;
  var replaceFirst = Kotlin.kotlin.text.replaceFirst_680rmw$;
  var substringAfterLast = Kotlin.kotlin.text.substringAfterLast_j4ogox$;
  var substringAfter = Kotlin.kotlin.text.substringAfter_j4ogox$;
  var substringBeforeLast = Kotlin.kotlin.text.substringBeforeLast_j4ogox$;
  var indexOf_0 = Kotlin.kotlin.collections.indexOf_2ws7j4$;
  function createProject$lambda$lambda(closure$name) {
    return function (it) {
      window.location.href = 'project.html?alias=' + closure$name;
      return Unit;
    };
  }
  function createProject$lambda(closure$name, closure$languages) {
    return function (error) {
      if (error == null) {
        addLanguages(closure$name, closure$languages).then(createProject$lambda$lambda(closure$name));
      }
    };
  }
  function createProject(name, alias, languages) {
    var json = createJson();
    var types = '"types": {' + '"0": "label",' + '"1": "button",' + '"2": "alert",' + '"3": "error",' + '"4": "placeholder",' + '"5": "warning"' + '}';
    json[name] = JSON.parse('{ ' + '"' + 'name' + '"' + ' : ' + '"' + name + '"' + ',' + ('"' + 'alias' + '"' + ' : ' + '"' + alias + '"' + ', ' + types + ' }'));
    dbRef.update(json, createProject$lambda(name, languages));
    return 'success';
  }
  function addScreens(name, names) {
    addStrings('screens', name, names.slice());
  }
  function addTypes(name, names) {
    addStrings('types', name, names.slice());
  }
  function getProjects$lambda$lambda$lambda(closure$languages) {
    return function (lang, idx) {
      closure$languages[closure$languages.length] = lang['langCode'].toString();
    };
  }
  function getProjects$lambda$lambda(closure$projects) {
    return function (child) {
      var project = child.toJSON();
      var languages = [];
      Object_0().values(project['languages']).forEach(getProjects$lambda$lambda$lambda(languages));
      var element = hashMapOf([to('name', project['name'].toString()), to('alias', project['alias'].toString()), to('languages', languages)]);
      closure$projects.add_11rb$(element);
    };
  }
  var copyToArray = Kotlin.kotlin.collections.copyToArray;
  function getProjects$lambda(closure$projects, closure$completion) {
    return function (snapshot) {
      snapshot.forEach(getProjects$lambda$lambda(closure$projects));
      closure$completion(copyToArray(closure$projects));
    };
  }
  function getProjects(completion) {
    var projects = ArrayList_init();
    dbRef.on(Constants$FIREBASE$contentType$Companion_getInstance().VALUE, getProjects$lambda(projects, completion));
  }
  function getProject$lambda$lambda$lambda(value) {
    localizationKeys.add(toString(value['key']));
  }
  function getProject$lambda$lambda(value) {
    Object_0().values(value).forEach(getProject$lambda$lambda$lambda);
  }
  function getProject$lambda(closure$listener) {
    return function (snapshot) {
      var tmp$;
      var projectJson = snapshot.toJSON();
      console.log(projectJson);
      var localizations = snapshot.toJSON()['localization'];
      if (localizations != null) {
        Object_0().values(localizations).forEach(getProject$lambda$lambda);
      }
      closure$listener(Kotlin.isType(tmp$ = snapshot.toJSON(), Object) ? tmp$ : throwCCE());
    };
  }
  function getProject(name, listener) {
    var childRef = dbRef.child(name);
    childRef.on(Constants$FIREBASE$contentType$Companion_getInstance().VALUE, getProject$lambda(listener));
  }
  function addLanguages$lambda$lambda$lambda(closure$element, closure$contains) {
    return function (elem) {
      if (elem['langCode'] == closure$element['langCode']) {
        closure$contains.v = true;
      }
    };
  }
  function addLanguages$lambda$lambda$lambda$lambda$lambda$lambda(closure$addedLanguages, closure$values, closure$nextIndex, closure$singleObject, closure$localizationRef, closure$key, closure$idx) {
    return function (it) {
      var tmp$;
      for (tmp$ = 0; tmp$ !== it.length; ++tmp$) {
        var element = it[tmp$];
        var closure$addedLanguages_0 = closure$addedLanguages;
        var closure$values_0 = closure$values;
        var closure$nextIndex_0 = closure$nextIndex;
        closure$values_0[closure$nextIndex_0.v.toString()] = json([to('lang_key', closure$addedLanguages_0.get_za3lpa$(indexOf(it, element)).first), to('lang_value', element)]);
        closure$nextIndex_0.v += 1;
      }
      closure$singleObject['values'] = closure$values;
      console.log('singleObject', closure$singleObject);
      return closure$localizationRef.child(closure$key + '/' + closure$idx.toString()).set(closure$singleObject);
    };
  }
  function addLanguages$lambda$lambda$lambda$lambda$lambda(closure$addedLanguages, closure$localizationRef, closure$key) {
    return function (singleObject, idx) {
      var values = singleObject['values'];
      console.log('singleObject', singleObject);
      var nextIndex = {v: Object_0().keys(values).length};
      var firstValue = values['0'];
      var langKey = firstValue['lang_key'];
      var langValue = firstValue['lang_value'];
      var promises = ArrayList_init();
      var tmp$;
      tmp$ = closure$addedLanguages.iterator();
      while (tmp$.hasNext()) {
        var element = tmp$.next();
        var promise = YandexHelper$Companion_getInstance().translate_f372nr$(element.first, langValue, false, langKey);
        promises.add_11rb$(promise);
      }
      Promise.all(copyToArray(promises)).then(addLanguages$lambda$lambda$lambda$lambda$lambda$lambda(closure$addedLanguages, values, nextIndex, singleObject, closure$localizationRef, closure$key, idx));
    };
  }
  function addLanguages$lambda$lambda$lambda$lambda(closure$json, closure$addedLanguages, closure$localizationRef) {
    return function (key) {
      var objects = closure$json[key];
      console.log('objects', objects);
      Object_0().values(objects).forEach(addLanguages$lambda$lambda$lambda$lambda$lambda(closure$addedLanguages, closure$localizationRef, key));
    };
  }
  function addLanguages$lambda$lambda$lambda_0(closure$addedLanguages, closure$localizationRef) {
    return function (snapshot) {
      var json = snapshot.toJSON();
      if (json != null) {
        Object_0().keys(json).forEach(addLanguages$lambda$lambda$lambda$lambda(json, closure$addedLanguages, closure$localizationRef));
      }
    };
  }
  function addLanguages$lambda$lambda$lambda_1(closure$success, closure$failure) {
    return function (error) {
      if (error == null) {
        closure$success('success');
      }
       else {
        closure$failure(Kotlin.newThrowable('error'));
      }
    };
  }
  function addLanguages$lambda$lambda(closure$languages, closure$name, closure$childRef, closure$success, closure$failure) {
    return function (snapshot) {
      var tmp$, tmp$_0;
      var snapshotArray = Object.values(snapshot.toJSON());
      var addedLanguages = ArrayList_init();
      var needsToUpdate = false;
      tmp$ = closure$languages;
      for (tmp$_0 = 0; tmp$_0 !== tmp$.length; ++tmp$_0) {
        var language = tmp$[tmp$_0];
        var element = json([to('langCode', language.first), to('langName', language.second)]);
        var contains = {v: false};
        snapshotArray.forEach(addLanguages$lambda$lambda$lambda(element, contains));
        if (!contains.v) {
          snapshotArray.push(element);
          addedLanguages.add_11rb$(language);
          needsToUpdate = true;
        }
      }
      if (needsToUpdate) {
        var localizationRef = dbRef.child(closure$name + '/localization');
        localizationRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(addLanguages$lambda$lambda$lambda_0(addedLanguages, localizationRef));
        closure$childRef.set(snapshotArray, addLanguages$lambda$lambda$lambda_1(closure$success, closure$failure));
      }
    };
  }
  function addLanguages$lambda$lambda$lambda_2(closure$success, closure$failure) {
    return function (error) {
      if (error == null) {
        closure$success('success');
      }
       else {
        closure$failure(Kotlin.newThrowable('error'));
      }
    };
  }
  function addLanguages$lambda$lambda_0(closure$languages, closure$childRef, closure$success, closure$failure) {
    return function (f) {
      var tmp$, tmp$_0;
      var snapshotArray = json([]);
      tmp$ = closure$languages;
      for (tmp$_0 = 0; tmp$_0 !== tmp$.length; ++tmp$_0) {
        var language = tmp$[tmp$_0];
        snapshotArray[indexOf(closure$languages, language).toString()] = json([to('langCode', language.first), to('langName', language.second)]);
      }
      closure$childRef.set(snapshotArray, addLanguages$lambda$lambda$lambda_2(closure$success, closure$failure));
    };
  }
  function addLanguages$lambda(closure$childRef, closure$languages, closure$name) {
    return function (success, failure) {
      var tmp$;
      Kotlin.isType(tmp$ = closure$childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(addLanguages$lambda$lambda(closure$languages, closure$name, closure$childRef, success, failure)).catch(addLanguages$lambda$lambda_0(closure$languages, closure$childRef, success, failure)), Object.getPrototypeOf(kotlin.Unit).constructor) ? tmp$ : null;
      return Unit;
    };
  }
  function addLanguages(name, languages) {
    var childRef = dbRef.child(name + '/languages');
    return new Promise(addLanguages$lambda(childRef, languages, name));
  }
  function filterScreens$lambda(closure$callBack) {
    return function (snapshot) {
      var tmp$;
      closure$callBack(Kotlin.isType(tmp$ = snapshot.toJSON(), Object) ? tmp$ : throwCCE());
    };
  }
  function filterScreens$lambda_0(error) {
    alert(error.message);
  }
  function filterScreens(projectName, name, callBack) {
    var project = dbRef.child(projectName + '/localization/' + name);
    project.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(filterScreens$lambda(callBack)).catch(filterScreens$lambda_0);
  }
  function setEditing$lambda$lambda(closure$index, closure$key) {
    return function (el, idx) {
      closure$index.v = idx.toString();
      return el.key == closure$key;
    };
  }
  function setEditing$lambda(closure$key, closure$childRef, closure$editing) {
    return function (snapshot) {
      if (!equals(typeof snapshot, 'undefined') && snapshot.toJSON() != null) {
        var index = {v: ''};
        Object_0().values(snapshot.toJSON()).find(setEditing$lambda$lambda(index, closure$key));
        closure$childRef.child(index.v + '/isEditing').set(closure$editing);
      }
    };
  }
  function setEditing(editing, projectName, screen, key) {
    var childRef = dbRef.child(projectName + '/localization/' + screen);
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(setEditing$lambda(key, childRef, editing));
  }
  function addStrings$lambda$lambda(error) {
    if (error == null) {
      console.log('success');
    }
     else {
      console.log(error);
    }
  }
  function addStrings$lambda(closure$names, closure$name, closure$childRef) {
    return function (snapshot) {
      var tmp$, tmp$_0;
      var json = snapshot.toJSON();
      if (json == null) {
        json = createJson();
      }
      var values = Object_0().values(json);
      tmp$ = closure$names;
      for (tmp$_0 = 0; tmp$_0 !== tmp$.length; ++tmp$_0) {
        var _name = tmp$[tmp$_0];
        json[values.length + indexOf(closure$names, _name)] = closure$name;
      }
      closure$childRef.update(json, addStrings$lambda$lambda);
    };
  }
  function addStrings(child, name, names) {
    var tmp$;
    var array = [];
    for (tmp$ = 0; tmp$ !== names.length; ++tmp$) {
      var _name = names[tmp$];
      array.push(_name);
    }
    var childRef = dbRef.child(name + '/' + child);
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(addStrings$lambda(names, name, childRef));
  }
  function removeValueFromChildArray$lambda$lambda(closure$value, closure$child) {
    return function (error) {
      if (error == null) {
        console.log(closure$value + ' of ' + closure$child + ' deleted');
      }
       else {
        console.log(error);
      }
    };
  }
  function removeValueFromChildArray$lambda(closure$value, closure$childRef, closure$child) {
    return function (snapshot) {
      var tmp$, tmp$_0, tmp$_1;
      var json = snapshot.toJSON();
      var values = Object_0().values(json);
      var index = values.indexOf(closure$value).toString();
      if (!equals(index, undefined)) {
        tmp$_0 = toInt(index);
        tmp$_1 = typeof (tmp$ = values.length - 1) === 'number' ? tmp$ : throwCCE();
        for (var i = tmp$_0; i <= tmp$_1; i++) {
          json[i.toString()] = json[(i + 1 | 0).toString()];
        }
        json[(values.length - 1).toString()] = null;
        console.log(JSON.stringify(json, null, 4));
        closure$childRef.update(json, removeValueFromChildArray$lambda$lambda(closure$value, closure$child));
      }
    };
  }
  function removeValueFromChildArray(value, child, name) {
    var childRef = dbRef.child(name + '/' + child);
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(removeValueFromChildArray$lambda(value, childRef, child));
  }
  function removeLocalizaton$lambda$lambda(closure$snapshot, closure$indexOfScreen, closure$key) {
    return function (el, idx) {
      closure$indexOfScreen.v = Object_0().keys(closure$snapshot.toJSON())[toInt(idx.toString())].toString();
      return el['key'] == closure$key;
    };
  }
  function removeLocalizaton$lambda$lambda_0(closure$index, closure$lang_value) {
    return function (el, idx) {
      closure$index.v = idx.toString();
      return el['lang_value'] == closure$lang_value;
    };
  }
  function removeLocalizaton$lambda$lambda_1(closure$itemToDelete) {
    return function (error) {
      if (error == null) {
        console.log(JSON.stringify(closure$itemToDelete, null, 4));
      }
       else {
        console.log(error);
      }
    };
  }
  function removeLocalizaton$lambda(closure$indexOfScreen, closure$key, closure$lang_value, closure$childRef) {
    return function (snapshot) {
      var values = Object_0().values(snapshot.toJSON());
      var localization = values.find(removeLocalizaton$lambda$lambda(snapshot, closure$indexOfScreen, closure$key));
      var localizationValues = Object_0().values(localization['values']);
      var index = {v: ''};
      var itemToDelete = localizationValues.find(removeLocalizaton$lambda$lambda_0(index, closure$lang_value));
      itemToDelete['lang_value'] = '';
      closure$childRef.child(closure$indexOfScreen.v + '/values/' + index.v).set(itemToDelete, removeLocalizaton$lambda$lambda_1(itemToDelete));
    };
  }
  function removeLocalizaton(name, screen, key, lang_value) {
    var childRef = dbRef.child(name + '/localization/' + screen);
    var indexOfScreen = {v: ''};
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE, removeLocalizaton$lambda(indexOfScreen, key, lang_value, childRef));
  }
  function removeRow$lambda$lambda(closure$index, closure$key) {
    return function (el, idx) {
      closure$index.v = idx.toString();
      return el.key == closure$key;
    };
  }
  function removeRow$lambda$lambda_0(closure$key) {
    return function (error) {
      if (error != null) {
        alert(error.toString());
      }
       else {
        localizationKeys.delete(closure$key);
      }
    };
  }
  function removeRow$lambda(closure$key, closure$screen, closure$projectName, closure$childRef) {
    return function (snapshot) {
      var tmp$, tmp$_0, tmp$_1;
      var json = snapshot.toJSON();
      var values = Object_0().values(json);
      var index = {v: ''};
      values.find(removeRow$lambda$lambda(index, closure$key));
      if (values.length > 1) {
        tmp$_0 = toInt(index.v);
        tmp$_1 = typeof (tmp$ = values.length - 1) === 'number' ? tmp$ : throwCCE();
        for (var i = tmp$_0; i <= tmp$_1; i++) {
          json[i.toString()] = json[(i + 1 | 0).toString()];
        }
        json[(values.length - 1).toString()] = null;
      }
       else {
        json['0'] = null;
        removeValueFromChildArray(closure$screen, 'screens', closure$projectName);
      }
      closure$childRef.update(json, removeRow$lambda$lambda_0(closure$key));
    };
  }
  function removeRow(projectName, screen, key) {
    var childRef = dbRef.child(projectName + '/localization/' + screen);
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(removeRow$lambda(key, screen, projectName, childRef));
  }
  function editLocalization$lambda$lambda(closure$snapshot, closure$indexOfScreen, closure$key) {
    return function (el, idx) {
      closure$indexOfScreen.v = Object_0().keys(closure$snapshot.toJSON())[toInt(idx.toString())].toString();
      return el['key'] == closure$key;
    };
  }
  function editLocalization$lambda$lambda_0(closure$index, closure$languageCode) {
    return function (el, idx) {
      closure$index.v = idx.toString();
      return el['lang_key'] == closure$languageCode;
    };
  }
  function editLocalization$lambda$lambda_1(closure$value) {
    return function (error) {
      if (error == null) {
        console.log(closure$value);
      }
       else {
        console.log(error);
      }
    };
  }
  function editLocalization$lambda(closure$key, closure$languageCode, closure$childRef, closure$value) {
    return function (snapshot) {
      var indexOfScreen = {v: ''};
      var values = Object_0().values(snapshot.toJSON());
      var localization = values.find(editLocalization$lambda$lambda(snapshot, indexOfScreen, closure$key));
      var localizationValues = Object_0().values(localization['values']);
      var index = {v: ''};
      localizationValues.find(editLocalization$lambda$lambda_0(index, closure$languageCode));
      closure$childRef.child(indexOfScreen.v + '/values/' + index.v + '/lang_value').set(closure$value, editLocalization$lambda$lambda_1(closure$value));
    };
  }
  function editLocalization(name, screen, key, languageCode, value) {
    var childRef = dbRef.child(name + '/localization/' + screen);
    childRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(editLocalization$lambda(key, languageCode, childRef, value));
  }
  function deleteProject$lambda$lambda(closure$completion) {
    return function (error) {
      closure$completion(error);
    };
  }
  function deleteProject$lambda(closure$name, closure$completion) {
    return function (snapshot) {
      var newValue = snapshot.toJSON();
      newValue[closure$name] = null;
      dbRef.update(newValue, deleteProject$lambda$lambda(closure$completion));
    };
  }
  function deleteProject(name, completion) {
    dbRef.once(Constants$FIREBASE$contentType$Companion_getInstance().VALUE).then(deleteProject$lambda(name, completion));
  }
  function existKeyInProject(key) {
    return localizationKeys.has(key);
  }
  function createJson() {
    return {};
  }
  function YandexHelper() {
    YandexHelper$Companion_getInstance();
  }
  var LinkedHashMap_init = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$;
  function YandexHelper$Companion() {
    YandexHelper$Companion_instance = this;
    this.supportedLanguages_0 = LinkedHashMap_init();
  }
  function YandexHelper$Companion$translate$lambda$lambda(closure$req, closure$res, closure$rej) {
    return function (it) {
      var tmp$;
      var response = JSON.parse(closure$req.responseText);
      if (response['code'] == '200') {
        closure$res(first(Kotlin.isArray(tmp$ = response['text']) ? tmp$ : throwCCE()));
      }
       else {
        closure$rej(Kotlin.newThrowable(response['message'].toString()));
      }
      return Unit;
    };
  }
  function YandexHelper$Companion$translate$lambda$lambda_0(closure$rej) {
    return function (it) {
      closure$rej(Kotlin.newThrowable('error'));
      return Unit;
    };
  }
  function YandexHelper$Companion$translate$lambda(closure$url) {
    return function (res, rej) {
      var req = new XMLHttpRequest();
      req.open('POST', closure$url.toString(), true);
      req.onloadend = YandexHelper$Companion$translate$lambda$lambda(req, res, rej);
      req.onerror = YandexHelper$Companion$translate$lambda$lambda_0(rej);
      req.send();
      return Unit;
    };
  }
  YandexHelper$Companion.prototype.translate_f372nr$ = function (to, text, detection, from) {
    if (detection === void 0)
      detection = true;
    if (from === void 0)
      from = '';
    var fromLang = from;
    if (detection) {
      fromLang = this.detectLanguage_0(text);
    }
    var url = new URL(Constants$YANDEX$Companion_getInstance().TRANSLATE_URL);
    var searchParams = new URLSearchParams();
    searchParams.append('key', Constants$YANDEX$Companion_getInstance().KEY);
    searchParams.append('text', text);
    searchParams.append('lang', fromLang + '-' + to);
    searchParams.append('format', 'plain');
    url.search = searchParams.toString();
    return new Promise(YandexHelper$Companion$translate$lambda(url));
  };
  function YandexHelper$Companion$detectLanguage$lambda(closure$req, closure$detectedLang) {
    return function (it) {
      var response = JSON.parse(closure$req.responseText);
      if (response['code'] == '200') {
        closure$detectedLang.v = response['lang'].toString();
      }
      return Unit;
    };
  }
  YandexHelper$Companion.prototype.detectLanguage_0 = function (text) {
    var url = new URL(Constants$YANDEX$Companion_getInstance().DETECTION_URL);
    var searchParams = new URLSearchParams();
    searchParams.append('key', Constants$YANDEX$Companion_getInstance().KEY);
    searchParams.append('text', text);
    url.search = searchParams.toString();
    var req = new XMLHttpRequest();
    req.open('POST', url.toString(), false);
    var detectedLang = {v: ''};
    req.onloadend = YandexHelper$Companion$detectLanguage$lambda(req, detectedLang);
    req.send();
    return detectedLang.v;
  };
  function YandexHelper$Companion$supportedLanguages$lambda$lambda$lambda(closure$langs, this$YandexHelper$) {
    return function (element) {
      var $receiver = this$YandexHelper$.supportedLanguages_0;
      var key = element.toString();
      var value = closure$langs[element].toString();
      $receiver.put_xwzc9p$(key, value);
    };
  }
  function YandexHelper$Companion$supportedLanguages$lambda$lambda$lambda_0(it) {
    return it.second;
  }
  var sortedWith = Kotlin.kotlin.collections.sortedWith_eknfly$;
  var wrapFunction = Kotlin.wrapFunction;
  var compareBy$lambda = wrapFunction(function () {
    var compareValues = Kotlin.kotlin.comparisons.compareValues_s00gnj$;
    return function (closure$selector) {
      return function (a, b) {
        var selector = closure$selector;
        return compareValues(selector(a), selector(b));
      };
    };
  });
  var Comparator = Kotlin.kotlin.Comparator;
  function Comparator$ObjectLiteral(closure$comparison) {
    this.closure$comparison = closure$comparison;
  }
  Comparator$ObjectLiteral.prototype.compare = function (a, b) {
    return this.closure$comparison(a, b);
  };
  Comparator$ObjectLiteral.$metadata$ = {kind: Kind_CLASS, interfaces: [Comparator]};
  function YandexHelper$Companion$supportedLanguages$lambda$lambda(closure$req, closure$reject, this$YandexHelper$, closure$success) {
    return function (it) {
      var response = JSON.parse(closure$req.responseText);
      if (response['code'] != null) {
        closure$reject(Kotlin.newThrowable(response['message'].toString()));
      }
      var langs = response['langs'];
      Object_0().keys(langs).forEach(YandexHelper$Companion$supportedLanguages$lambda$lambda$lambda(langs, this$YandexHelper$));
      closure$success(toMap(sortedWith(toList(this$YandexHelper$.supportedLanguages_0), new Comparator$ObjectLiteral(compareBy$lambda(YandexHelper$Companion$supportedLanguages$lambda$lambda$lambda_0)))));
      return Unit;
    };
  }
  function YandexHelper$Companion$supportedLanguages$lambda(this$YandexHelper$, closure$ui) {
    return function (success, reject) {
      if (!this$YandexHelper$.supportedLanguages_0.isEmpty()) {
        success(this$YandexHelper$.supportedLanguages_0);
      }
      var url = new URL(Constants$YANDEX$Companion_getInstance().LANGUAGES_URL);
      var searchParams = new URLSearchParams();
      searchParams.append('key', Constants$YANDEX$Companion_getInstance().KEY);
      searchParams.append('ui', closure$ui);
      url.search = searchParams.toString();
      var req = new XMLHttpRequest();
      req.open('POST', url.toString(), true);
      req.onloadend = YandexHelper$Companion$supportedLanguages$lambda$lambda(req, reject, this$YandexHelper$, success);
      req.send();
      return Unit;
    };
  }
  YandexHelper$Companion.prototype.supportedLanguages_61zpoe$ = function (ui) {
    if (ui === void 0)
      ui = 'en';
    return new Promise(YandexHelper$Companion$supportedLanguages$lambda(this, ui));
  };
  YandexHelper$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var YandexHelper$Companion_instance = null;
  function YandexHelper$Companion_getInstance() {
    if (YandexHelper$Companion_instance === null) {
      new YandexHelper$Companion();
    }
    return YandexHelper$Companion_instance;
  }
  YandexHelper.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'YandexHelper',
    interfaces: []
  };
  function Object_0() {
    return Object;
  }
  function Constants() {
  }
  function Constants$FIREBASE() {
  }
  function Constants$FIREBASE$contentType() {
    Constants$FIREBASE$contentType$Companion_getInstance();
  }
  function Constants$FIREBASE$contentType$Companion() {
    Constants$FIREBASE$contentType$Companion_instance = this;
    this.VALUE = 'value';
    this.CHILD_ADDED = 'child_added';
    this.CHILD_CHANGED = 'child_changed';
    this.CHILD_REMOVED = 'child_removed';
    this.CHILD_MOVED = 'child_moved';
  }
  Constants$FIREBASE$contentType$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var Constants$FIREBASE$contentType$Companion_instance = null;
  function Constants$FIREBASE$contentType$Companion_getInstance() {
    if (Constants$FIREBASE$contentType$Companion_instance === null) {
      new Constants$FIREBASE$contentType$Companion();
    }
    return Constants$FIREBASE$contentType$Companion_instance;
  }
  Constants$FIREBASE$contentType.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'contentType',
    interfaces: []
  };
  Constants$FIREBASE.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'FIREBASE',
    interfaces: []
  };
  function Constants$YANDEX() {
    Constants$YANDEX$Companion_getInstance();
  }
  function Constants$YANDEX$Companion() {
    Constants$YANDEX$Companion_instance = this;
    this.KEY = 'trnsl.1.1.20180629T054817Z.31806ab54c4a97c8.96387b071cabbf73cd2338577c1c19060001fe66';
    this.DETECTION_URL = 'https://translate.yandex.net/api/v1.5/tr.json/detect';
    this.TRANSLATE_URL = 'https://translate.yandex.net/api/v1.5/tr.json/translate';
    this.LANGUAGES_URL = 'https://translate.yandex.net/api/v1.5/tr.json/getLangs';
  }
  Constants$YANDEX$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var Constants$YANDEX$Companion_instance = null;
  function Constants$YANDEX$Companion_getInstance() {
    if (Constants$YANDEX$Companion_instance === null) {
      new Constants$YANDEX$Companion();
    }
    return Constants$YANDEX$Companion_instance;
  }
  Constants$YANDEX.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'YANDEX',
    interfaces: []
  };
  Constants.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'Constants',
    interfaces: []
  };
  var firebase_0;
  var dbRef;
  var projectName;
  function main$lambda$lambda() {
    var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5;
    var createProjectForm = Kotlin.isType(tmp$ = document.getElementById('create_project_form'), HTMLFormElement) ? tmp$ : throwCCE();
    createProjectForm.reset();
    var select = Kotlin.isType(tmp$_0 = document.getElementById('language_select'), HTMLSelectElement) ? tmp$_0 : throwCCE();
    var modalElem = document.getElementById('modal1');
    modalElem != null ? (modalElem.removeAttribute('mode'), Unit) : null;
    var headerElem = Kotlin.isType(tmp$_1 = document.getElementById('add_project_header'), HTMLElement) ? tmp$_1 : throwCCE();
    headerElem.innerText = 'New Project';
    var projectNameInput = Kotlin.isType(tmp$_2 = document.getElementById('project_name'), HTMLInputElement) ? tmp$_2 : throwCCE();
    projectNameInput.className = 'validate';
    projectNameInput.disabled = false;
    var projectAliasInput = Kotlin.isType(tmp$_3 = document.getElementById('project_alias'), HTMLInputElement) ? tmp$_3 : throwCCE();
    projectAliasInput.className = 'validate';
    projectAliasInput.disabled = false;
    var index = 0;
    tmp$_4 = asList(select.options).size;
    for (var i = 0; i < tmp$_4; i++) {
      var _optionElement = Kotlin.isType(tmp$_5 = select.options[i], HTMLOptionElement) ? tmp$_5 : throwCCE();
      if (equals(_optionElement.value, 'en')) {
        _optionElement.selected = true;
        index = i;
        break;
      }
    }
  }
  function main$lambda$lambda_0() {
    return Unit;
  }
  function main$lambda$lambda$lambda$lambda$lambda() {
    return Unit;
  }
  function main$lambda$lambda$lambda$lambda(closure$projectName, closure$projectAlias, closure$it) {
    return function (event) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6;
      event.stopPropagation();
      var headerElem = Kotlin.isType(tmp$ = document.getElementById('add_project_header'), HTMLElement) ? tmp$ : throwCCE();
      headerElem.innerText = 'Edit Project';
      var projectNameInput = Kotlin.isType(tmp$_0 = document.getElementById('project_name'), HTMLInputElement) ? tmp$_0 : throwCCE();
      projectNameInput.value = closure$projectName.v;
      projectNameInput.className = '';
      var projectAliasInput = Kotlin.isType(tmp$_1 = document.getElementById('project_alias'), HTMLInputElement) ? tmp$_1 : throwCCE();
      projectAliasInput.value = closure$projectAlias;
      projectAliasInput.className = '';
      var select = Kotlin.isType(tmp$_2 = document.getElementById('language_select'), HTMLSelectElement) ? tmp$_2 : throwCCE();
      var languages = Kotlin.isArray(tmp$_3 = closure$it.get_11rb$('languages')) ? tmp$_3 : throwCCE();
      console.log(languages);
      for (tmp$_4 = 0; tmp$_4 !== languages.length; ++tmp$_4) {
        var language = languages[tmp$_4];
        tmp$_5 = asList(select.options).iterator();
        while (tmp$_5.hasNext()) {
          var option = tmp$_5.next();
          var optionElem = Kotlin.isType(tmp$_6 = option, HTMLOptionElement) ? tmp$_6 : throwCCE();
          if (optionElem.selected) {
            continue;
          }
          optionElem.selected = equals(optionElem.value, language) || equals(optionElem.value, 'en');
          console.log(option);
        }
      }
      var elems = document.querySelectorAll('select');
      M.FormSelect.init(elems, main$lambda$lambda$lambda$lambda$lambda);
      var modalElem = document.getElementById('modal1');
      modalElem != null ? (modalElem.setAttribute('mode', 'editing'), Unit) : null;
      var modal = M.Modal.getInstance(modalElem);
      modal.open();
      projectNameInput.focus();
      projectNameInput.disabled = true;
      projectAliasInput.focus();
      projectAliasInput.disabled = true;
    };
  }
  function main$lambda$lambda$lambda$lambda$lambda$lambda(closure$projectCard) {
    return function (it) {
      var tmp$, tmp$_0;
      if (it != null) {
        alert('error');
      }
       else {
        var elem = Kotlin.isType(tmp$ = document.getElementById(closure$projectCard.v.id), HTMLDivElement) ? tmp$ : throwCCE();
        var parent = Kotlin.isType(tmp$_0 = elem.parentElement, HTMLDivElement) ? tmp$_0 : throwCCE();
        var removedChild = parent.removeChild(elem);
      }
      return Unit;
    };
  }
  function main$lambda$lambda$lambda$lambda$lambda_0(closure$projectName, closure$projectCard) {
    return function (e) {
      deleteProject(closure$projectName.v, main$lambda$lambda$lambda$lambda$lambda$lambda(closure$projectCard));
    };
  }
  function main$lambda$lambda$lambda$lambda_0(closure$deleteElem, closure$projectCard) {
    return function (event) {
      var tmp$;
      event.stopPropagation();
      var projectName = {v: typeof (tmp$ = closure$deleteElem.getAttribute('data-project_name')) === 'string' ? tmp$ : throwCCE()};
      var modal = document.getElementById('confirm_modal');
      var instance = M.Modal.getInstance(modal);
      instance.open();
      var delete_0 = document.getElementById('confirm_modal_delete');
      delete_0 != null ? (delete_0.addEventListener('click', main$lambda$lambda$lambda$lambda$lambda_0(projectName, closure$projectCard)), Unit) : null;
    };
  }
  function main$lambda$lambda$lambda(closure$node) {
    return function (event) {
      var tmp$;
      var element = Kotlin.isType(tmp$ = closure$node, HTMLDivElement) ? tmp$ : throwCCE();
      var cardElement = element.firstElementChild;
      if (cardElement != null) {
        var projectAlias = cardElement.getAttribute('data-alias');
        if (!equals(projectAlias, 'new-project')) {
          window.location.href = './project.html?alias=' + toString(projectAlias);
        }
         else {
          var modalElem = document.getElementById('modal1');
          var modal = M.Modal.getInstance(modalElem);
          modal.open();
        }
      }
    };
  }
  function main$lambda$lambda_1(it) {
    var tmp$, tmp$_0;
    var divProjects = Kotlin.isType(tmp$ = document.getElementById('row'), HTMLDivElement) ? tmp$ : throwCCE();
    divProjects.innerHTML = '<div class="col s12 m3">\n' + '                    <div class="card" data-alias="new-project" data-target="modal1" id="new-project">\n' + '                        <div class="card-container">\n' + '                            <img src="images/icon-plus.png" alt="Add Project" height="36" width="36">\n' + '                            <p>Add Project<\/p>\n' + '                        <\/div>\n' + '                    <\/div>\n' + '                <\/div>';
    var tmp$_1;
    for (tmp$_1 = 0; tmp$_1 !== it.length; ++tmp$_1) {
      var element = it[tmp$_1];
      var tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6, tmp$_7, tmp$_8, tmp$_9, tmp$_10, tmp$_11, tmp$_12, tmp$_13, tmp$_14, tmp$_15, tmp$_16;
      var projectCard = {v: document.getElementById(toString(element.get_11rb$('alias')))};
      if (projectCard.v == null) {
        projectCard.v = Kotlin.isType(tmp$_2 = document.createElement('div'), HTMLDivElement) ? tmp$_2 : throwCCE();
        projectCard.v.className = 'col s12 m3';
        projectCard.v.id = toString(element.get_11rb$('alias'));
        var card = Kotlin.isType(tmp$_3 = document.createElement('div'), HTMLDivElement) ? tmp$_3 : throwCCE();
        card.className = 'card';
        card.setAttribute('data-alias', toString(element.get_11rb$('name')));
        var cardContext = Kotlin.isType(tmp$_4 = document.createElement('div'), HTMLDivElement) ? tmp$_4 : throwCCE();
        cardContext.className = 'card-content black-text';
        var cardTitle = Kotlin.isType(tmp$_5 = document.createElement('span'), HTMLSpanElement) ? tmp$_5 : throwCCE();
        cardTitle.className = 'card-title';
        cardTitle.innerText = toString(element.get_11rb$('name'));
        var alias = Kotlin.isType(tmp$_6 = document.createElement('p'), HTMLParagraphElement) ? tmp$_6 : throwCCE();
        var projectAlias = toString(element.get_11rb$('alias'));
        alias.innerText = projectAlias;
        var actionsEditElem = Kotlin.isType(tmp$_7 = document.createElement('div'), HTMLDivElement) ? tmp$_7 : throwCCE();
        actionsEditElem.className = 'actions';
        var deleteElem = Kotlin.isType(tmp$_8 = document.createElement('a'), HTMLElement) ? tmp$_8 : throwCCE();
        deleteElem.className = 'btn-floating btn-small waves-effect waves-light red';
        var projectName = {v: toString(element.get_11rb$('name'))};
        deleteElem.setAttribute('data-project_name', projectName.v);
        var deleteChildElem = Kotlin.isType(tmp$_9 = document.createElement('i'), HTMLElement) ? tmp$_9 : throwCCE();
        deleteChildElem.className = 'material-icons';
        deleteChildElem.innerText = 'clear';
        deleteElem.appendChild(deleteChildElem);
        var editElem = Kotlin.isType(tmp$_10 = document.createElement('a'), HTMLElement) ? tmp$_10 : throwCCE();
        editElem.className = 'btn-floating btn-small waves-effect waves-light light-blue edit_card';
        editElem.setAttribute('data-project_name', projectName.v);
        var editChildElem = Kotlin.isType(tmp$_11 = document.createElement('i'), HTMLElement) ? tmp$_11 : throwCCE();
        editChildElem.className = 'material-icons';
        editChildElem.innerText = 'edit';
        editElem.addEventListener('click', main$lambda$lambda$lambda$lambda(projectName, projectAlias, element));
        editElem.appendChild(editChildElem);
        actionsEditElem.appendChild(editElem);
        actionsEditElem.appendChild(deleteElem);
        deleteElem.addEventListener('click', main$lambda$lambda$lambda$lambda_0(deleteElem, projectCard));
        var platformContainer = Kotlin.isType(tmp$_12 = document.createElement('div'), HTMLDivElement) ? tmp$_12 : throwCCE();
        platformContainer.className = 'platform-container';
        var iosImage = Kotlin.isType(tmp$_13 = document.createElement('img'), HTMLImageElement) ? tmp$_13 : throwCCE();
        iosImage.src = 'images/icon-ios.png';
        iosImage.alt = 'iOS';
        iosImage.width = 24;
        iosImage.height = 24;
        var androidImage = Kotlin.isType(tmp$_14 = document.createElement('img'), HTMLImageElement) ? tmp$_14 : throwCCE();
        androidImage.src = 'images/icon-android.png';
        androidImage.alt = 'Android';
        androidImage.width = 24;
        androidImage.height = 24;
        var webImage = Kotlin.isType(tmp$_15 = document.createElement('img'), HTMLImageElement) ? tmp$_15 : throwCCE();
        webImage.src = 'images/icon-website.png';
        webImage.alt = 'Web';
        webImage.width = 24;
        webImage.height = 24;
        platformContainer.append(iosImage, androidImage, webImage);
        cardContext.append(cardTitle, alias, actionsEditElem, platformContainer);
        card.appendChild(cardContext);
        projectCard.v.appendChild(card);
        divProjects.appendChild(projectCard.v);
      }
      var loading = document.getElementById('indicator');
      if (loading != null) {
        divProjects.removeChild(Kotlin.isType(tmp$_16 = loading, HTMLElement) ? tmp$_16 : throwCCE());
      }
    }
    tmp$_0 = asList(divProjects.childNodes).iterator();
    while (tmp$_0.hasNext()) {
      var node = tmp$_0.next();
      node.addEventListener('click', main$lambda$lambda$lambda(node));
    }
    return Unit;
  }
  function main$lambda(it) {
    var elems = document.querySelectorAll('.modal');
    var params = json([to('onCloseEnd', main$lambda$lambda)]);
    M.Modal.init(elems, params);
    var confirmationModal = document.getElementById('confirm_modal');
    M.Modal.init(confirmationModal, main$lambda$lambda_0);
    setupLanguageOptions();
    getProjects(main$lambda$lambda_1);
    return Unit;
  }
  function main$lambda_0(it) {
    setupModal();
    setupCopyElement();
    return Unit;
  }
  function main$lambda$lambda_2(closure$languages, closure$languageCodes) {
    return function (language) {
      var tmp$, tmp$_0;
      closure$languages.add_11rb$(typeof (tmp$ = language['langName']) === 'string' ? tmp$ : throwCCE());
      closure$languageCodes.add_11rb$(typeof (tmp$_0 = language['langCode']) === 'string' ? tmp$_0 : throwCCE());
    };
  }
  function main$lambda$lambda_3(closure$screens) {
    return function (screen) {
      closure$screens[closure$screens.length] = screen;
    };
  }
  function main$lambda$lambda_4(closure$types) {
    return function (type) {
      closure$types.v[closure$types.v.length] = type;
    };
  }
  function main$lambda$lambda_5(closure$targetProjectAlias, closure$languageCodes, closure$languages, closure$language) {
    return function (it) {
      return window.open('./localization.html?alias=' + toString(closure$targetProjectAlias) + '&lng=' + closure$languageCodes.get_za3lpa$(closure$languages.indexOf_11rb$(closure$language)), '_blank');
    };
  }
  function main$lambda$lambda_6(closure$localization, closure$index, closure$tableBody) {
    return function (screen) {
      var tmp$;
      var screenLocalization = Kotlin.isType(tmp$ = closure$localization[screen], Object) ? tmp$ : null;
      var $receiver = tableRowDataFromScreen(screen, screenLocalization);
      var tmp$_0;
      for (tmp$_0 = 0; tmp$_0 !== $receiver.length; ++tmp$_0) {
        var element = $receiver[tmp$_0];
        var closure$index_0 = closure$index;
        var closure$tableBody_0 = closure$tableBody;
        closure$index_0.v = closure$index_0.v + 1 | 0;
        var tr = tableRowElementFromTableRowData(element, closure$index_0.v);
        closure$tableBody_0.appendChild(tr);
      }
    };
  }
  function main$lambda$lambda$lambda_0(closure$localization, closure$index, closure$tableBody) {
    return function (screen) {
      var tmp$;
      var screenLocalization = Kotlin.isType(tmp$ = closure$localization[screen], Object) ? tmp$ : null;
      var $receiver = tableRowDataFromScreen(screen, screenLocalization);
      var tmp$_0;
      for (tmp$_0 = 0; tmp$_0 !== $receiver.length; ++tmp$_0) {
        var element = $receiver[tmp$_0];
        var closure$index_0 = closure$index;
        var closure$tableBody_0 = closure$tableBody;
        closure$index_0.v = closure$index_0.v + 1 | 0;
        var tr = tableRowElementFromTableRowData(element, closure$index_0.v);
        closure$tableBody_0.appendChild(tr);
      }
    };
  }
  function main$lambda$lambda$lambda$lambda_1(closure$localizationsOfscreens, closure$key) {
    return function (el) {
      closure$localizationsOfscreens[closure$localizationsOfscreens.length] = json([to(closure$key, el)]);
    };
  }
  function main$lambda$lambda$lambda_1(closure$localization, closure$localizationsOfscreens) {
    return function (key) {
      var tmp$;
      var elem = Kotlin.isType(tmp$ = closure$localization != null ? closure$localization[key] : null, Object) ? tmp$ : throwCCE();
      Object_0().values(elem).forEach(main$lambda$lambda$lambda$lambda_1(closure$localizationsOfscreens, key));
    };
  }
  function main$lambda$lambda$lambda$lambda_2(closure$searchText, closure$contains) {
    return function (el) {
      var x = contains(toString(el['lang_value']), closure$searchText, true);
      if (x) {
        closure$contains.v = x;
      }
    };
  }
  function main$lambda$lambda$lambda_2(closure$searchText) {
    return function (it) {
      var tmp$;
      var contains = {v: false};
      var values = Kotlin.isType(tmp$ = Object_0().values(it)[0]['values'], Object) ? tmp$ : throwCCE();
      Object_0().values(values).forEach(main$lambda$lambda$lambda$lambda_2(closure$searchText, contains));
      return contains.v;
    };
  }
  function main$lambda$lambda_7(closure$select, closure$input, closure$tableBody, closure$index, closure$localization, closure$it) {
    return function (e) {
      closure$select.selectedIndex = 2;
      var searchText = closure$input.value;
      closure$tableBody.innerHTML = '';
      closure$index.v = 0;
      if (searchText.length === 0) {
        if (closure$localization != null) {
          Object_0().values(closure$it['screens']).forEach(main$lambda$lambda$lambda_0(closure$localization, closure$index, closure$tableBody));
        }
      }
       else {
        var localizationsOfscreens = [];
        Object_0().keys(closure$localization).forEach(main$lambda$lambda$lambda_1(closure$localization, localizationsOfscreens));
        var predicate = main$lambda$lambda$lambda_2(searchText);
        var destination = ArrayList_init();
        var tmp$;
        for (tmp$ = 0; tmp$ !== localizationsOfscreens.length; ++tmp$) {
          var element = localizationsOfscreens[tmp$];
          if (predicate(element))
            destination.add_11rb$(element);
        }
        var filteredScreens = destination;
        var tmp$_0;
        tmp$_0 = filteredScreens.iterator();
        while (tmp$_0.hasNext()) {
          var element_0 = tmp$_0.next();
          var closure$index_0 = closure$index;
          var closure$tableBody_0 = closure$tableBody;
          var screenName = Object_0().keys(element_0)[0].toString();
          var $receiver = tableRowDataFromScreen(screenName, element_0);
          var tmp$_1;
          for (tmp$_1 = 0; tmp$_1 !== $receiver.length; ++tmp$_1) {
            var element_1 = $receiver[tmp$_1];
            closure$index_0.v = closure$index_0.v + 1 | 0;
            var tr = tableRowElementFromTableRowData(element_1, closure$index_0.v);
            closure$tableBody_0.appendChild(tr);
          }
        }
      }
    };
  }
  function main$lambda$lambda$lambda_3(closure$select, closure$index, closure$tableBody) {
    return function (screen) {
      var tmp$;
      var $receiver = tableRowDataFromScreen((Kotlin.isType(tmp$ = closure$select.selectedOptions[0], HTMLOptionElement) ? tmp$ : throwCCE()).value, screen);
      var tmp$_0;
      for (tmp$_0 = 0; tmp$_0 !== $receiver.length; ++tmp$_0) {
        var element = $receiver[tmp$_0];
        var closure$index_0 = closure$index;
        var closure$tableBody_0 = closure$tableBody;
        closure$index_0.v = closure$index_0.v + 1 | 0;
        var tr = tableRowElementFromTableRowData(element, closure$index_0.v);
        closure$tableBody_0.appendChild(tr);
      }
    };
  }
  function main$lambda$lambda$lambda_4(closure$localization, closure$index, closure$tableBody) {
    return function (screen) {
      var tmp$;
      var screenLocalization = Kotlin.isType(tmp$ = closure$localization[screen], Object) ? tmp$ : null;
      var $receiver = tableRowDataFromScreen(screen, screenLocalization);
      var tmp$_0;
      for (tmp$_0 = 0; tmp$_0 !== $receiver.length; ++tmp$_0) {
        var element = $receiver[tmp$_0];
        var closure$index_0 = closure$index;
        var closure$tableBody_0 = closure$tableBody;
        closure$index_0.v = closure$index_0.v + 1 | 0;
        var tr = tableRowElementFromTableRowData(element, closure$index_0.v);
        closure$tableBody_0.appendChild(tr);
      }
    };
  }
  function main$lambda$lambda_8(closure$input, closure$tableBody, closure$index, closure$select, closure$localization, closure$it) {
    return function (f) {
      var tmp$, tmp$_0;
      closure$input.value = '';
      closure$tableBody.innerHTML = '';
      closure$index.v = 0;
      if (!equals((Kotlin.isType(tmp$ = closure$select.selectedOptions[0], HTMLOptionElement) ? tmp$ : throwCCE()).value, 'all')) {
        filterScreens(projectName, (Kotlin.isType(tmp$_0 = closure$select.selectedOptions[0], HTMLOptionElement) ? tmp$_0 : throwCCE()).value, main$lambda$lambda$lambda_3(closure$select, closure$index, closure$tableBody));
      }
       else {
        if (closure$localization != null) {
          Object_0().values(closure$it['screens']).forEach(main$lambda$lambda$lambda_4(closure$localization, closure$index, closure$tableBody));
        }
      }
      return Unit;
    };
  }
  function main$lambda$lambda_9() {
    return Unit;
  }
  function main$lambda_1(closure$collectionElement, closure$targetProjectAlias) {
    return function (it) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6, tmp$_7, tmp$_8, tmp$_9, tmp$_10, tmp$_11, tmp$_12, tmp$_13, tmp$_14, tmp$_15, tmp$_16, tmp$_17, tmp$_18, tmp$_19, tmp$_20, tmp$_21, tmp$_22, tmp$_23, tmp$_24, tmp$_25, tmp$_26, tmp$_27, tmp$_28, tmp$_29, tmp$_30, tmp$_31;
      addLanguageInputsToPopup(it);
      projectName = typeof (tmp$ = it['name']) === 'string' ? tmp$ : throwCCE();
      var projectAlias = typeof (tmp$_0 = it['alias']) === 'string' ? tmp$_0 : throwCCE();
      var languages = ArrayList_init();
      var languageCodes = ArrayList_init();
      var languagesJson = Kotlin.isType(tmp$_1 = it['languages'], Object) ? tmp$_1 : throwCCE();
      Object.values(languagesJson).forEach(main$lambda$lambda_2(languages, languageCodes));
      var screens = [];
      var screensJson = Kotlin.isType(tmp$_2 = it['screens'], Object) ? tmp$_2 : null;
      if (screensJson != null) {
        Object.values(screensJson).forEach(main$lambda$lambda_3(screens));
        initScreenAutocompleteList(screens);
      }
      var types = {v: []};
      var typesJson = Kotlin.isType(tmp$_3 = it['types'], Object) ? tmp$_3 : null;
      if (typesJson != null) {
        Object.values(typesJson).forEach(main$lambda$lambda_4(types));
        initTypeAutocompleteList(types.v);
      }
      if (closure$collectionElement != null) {
        var headerContainer = Kotlin.isType(tmp$_4 = document.createElement('div'), HTMLDivElement) ? tmp$_4 : throwCCE();
        addClass(headerContainer, ['header-container']);
        var headerContainerBase = Kotlin.isType(tmp$_5 = document.createElement('div'), HTMLDivElement) ? tmp$_5 : throwCCE();
        addClass(headerContainerBase, ['header-container-base']);
        var projectNameAndAlias = Kotlin.isType(tmp$_6 = document.createElement('div'), HTMLDivElement) ? tmp$_6 : throwCCE();
        var HProjectName = Kotlin.isType(tmp$_7 = document.createElement('h5'), HTMLHeadingElement) ? tmp$_7 : throwCCE();
        HProjectName.innerText = projectName;
        var HProjectAlias = Kotlin.isType(tmp$_8 = document.createElement('h6'), HTMLHeadingElement) ? tmp$_8 : throwCCE();
        HProjectAlias.innerText = projectAlias;
        projectNameAndAlias.append(HProjectName, HProjectAlias);
        var exportButton = Kotlin.isType(tmp$_9 = document.createElement('div'), HTMLDivElement) ? tmp$_9 : throwCCE();
        addClass(exportButton, ['export_button']);
        var dropdownTrigger = document.createElement('a');
        addClass(dropdownTrigger, ['dropdown-trigger btn']);
        dropdownTrigger.setAttribute('href', '#');
        dropdownTrigger.setAttribute('data-target', 'dropdown1');
        dropdownTrigger.innerHTML = 'Export';
        var dropdownContent = Kotlin.isType(tmp$_10 = document.createElement('ul'), HTMLUListElement) ? tmp$_10 : throwCCE();
        addClass(dropdownContent, ['dropdown-content']);
        dropdownContent.id = 'dropdown1';
        var exportiOS = Kotlin.isType(tmp$_11 = document.createElement('li'), HTMLLIElement) ? tmp$_11 : throwCCE();
        exportiOS.innerHTML = '<a href="#!" id="export_ios">iOS<\/a>';
        var divider = Kotlin.isType(tmp$_12 = document.createElement('li'), HTMLLIElement) ? tmp$_12 : throwCCE();
        addClass(divider, ['divider']);
        divider.tabIndex = -1;
        var exportAndroid = Kotlin.isType(tmp$_13 = document.createElement('li'), HTMLLIElement) ? tmp$_13 : throwCCE();
        exportAndroid.innerHTML = '<a href="#!" id="export_android">Andriod<\/a>';
        var exportWeb = Kotlin.isType(tmp$_14 = document.createElement('li'), HTMLLIElement) ? tmp$_14 : throwCCE();
        exportWeb.innerHTML = '<a href="#!" id="export_web">Web<\/a>';
        dropdownContent.append(exportiOS, divider, exportAndroid, divider.cloneNode(true), exportWeb);
        exportButton.append(dropdownTrigger, dropdownContent);
        headerContainerBase.append(projectNameAndAlias);
        headerContainer.appendChild(headerContainerBase);
        var table = Kotlin.isType(tmp$_15 = document.createElement('table'), HTMLTableElement) ? tmp$_15 : throwCCE();
        addClass(table, ['highlight centered responsive-table']);
        var tableHead = document.createElement('thead');
        var row = Kotlin.isType(tmp$_16 = document.createElement('tr'), HTMLTableRowElement) ? tmp$_16 : throwCCE();
        var tableIndex = Kotlin.isType(tmp$_17 = document.createElement('th'), HTMLTableCellElement) ? tmp$_17 : throwCCE();
        addClass(tableIndex, ['table_index']);
        tableIndex.innerText = 'N';
        var tableScreen = Kotlin.isType(tmp$_18 = document.createElement('th'), HTMLTableCellElement) ? tmp$_18 : throwCCE();
        addClass(tableScreen, ['table_screen']);
        tableScreen.innerText = 'Screen';
        var tableKey = Kotlin.isType(tmp$_19 = document.createElement('th'), HTMLTableCellElement) ? tmp$_19 : throwCCE();
        tableKey.innerText = 'Key';
        var tableComment = Kotlin.isType(tmp$_20 = document.createElement('th'), HTMLTableCellElement) ? tmp$_20 : throwCCE();
        tableComment.innerText = 'Comment';
        tableComment.hidden = true;
        row.append(tableIndex, tableScreen, tableKey);
        row.append(tableIndex, tableScreen, tableKey, tableComment);
        tmp$_21 = languages.iterator();
        while (tmp$_21.hasNext()) {
          var language = tmp$_21.next();
          var th = Kotlin.isType(tmp$_22 = document.createElement('th'), HTMLTableCellElement) ? tmp$_22 : throwCCE();
          th.innerText = language;
          th.onclick = main$lambda$lambda_5(closure$targetProjectAlias, languageCodes, languages, language);
          row.appendChild(th);
        }
        var options = Kotlin.isType(tmp$_23 = document.createElement('th'), HTMLTableCellElement) ? tmp$_23 : throwCCE();
        addClass(options, ['head_options']);
        options.innerText = '   ';
        row.appendChild(options);
        tableHead.appendChild(row);
        var tableBody = document.createElement('tbody');
        var index = {v: 0};
        var localization = Kotlin.isType(tmp$_24 = it['localization'], Object) ? tmp$_24 : null;
        if (localization != null) {
          Object_0().values(it['screens']).forEach(main$lambda$lambda_6(localization, index, tableBody));
        }
         else {
          var emptyContentElem = document.createElement('p');
          emptyContentElem.innerHTML = 'Localization is empty';
          emptyContentElem.className = 'empty_data_content';
          tableBody.appendChild(emptyContentElem);
        }
        table.append(tableHead, tableBody);
        if (screens.length > 0) {
          var comboBox = Kotlin.isType(tmp$_25 = document.createElement('div'), HTMLDivElement) ? tmp$_25 : throwCCE();
          addClass(comboBox, ['input-field']);
          addClass(comboBox, ['col']);
          addClass(comboBox, ['s3']);
          comboBox.id = 'screens_combobox';
          var select = Kotlin.isType(tmp$_26 = document.createElement('select'), HTMLSelectElement) ? tmp$_26 : throwCCE();
          var allOption = Kotlin.isType(tmp$_27 = document.createElement('option'), HTMLOptionElement) ? tmp$_27 : throwCCE();
          allOption.value = 'all';
          allOption.text = 'All';
          allOption.selected = true;
          select.appendChild(allOption);
          var tmp$_32;
          for (tmp$_32 = 0; tmp$_32 !== screens.length; ++tmp$_32) {
            var element = screens[tmp$_32];
            var tmp$_33;
            var option = Kotlin.isType(tmp$_33 = document.createElement('option'), HTMLOptionElement) ? tmp$_33 : throwCCE();
            option.value = element;
            option.text = element;
            select.appendChild(option);
          }
          comboBox.append(select);
          var searchField = document.createElement('div');
          addClass(searchField, ['input-field col s9']);
          var icon = document.createElement('i');
          addClass(icon, ['material-icons prefix']);
          icon.innerHTML = 'search';
          var input = Kotlin.isType(tmp$_28 = document.createElement('input'), HTMLInputElement) ? tmp$_28 : throwCCE();
          addClass(input, ['validate']);
          input.type = 'text';
          input.id = 'icon_search';
          var placeholder = Kotlin.isType(tmp$_29 = document.createElement('label'), HTMLLabelElement) ? tmp$_29 : throwCCE();
          placeholder.htmlFor = 'icon_search';
          placeholder.innerText = 'Search';
          searchField.append(icon, input, placeholder);
          var filterContianer = Kotlin.isType(tmp$_30 = document.createElement('div'), HTMLDivElement) ? tmp$_30 : throwCCE();
          filterContianer.className = 'row';
          filterContianer.appendChild(searchField);
          filterContianer.appendChild(comboBox);
          headerContainerBase.appendChild(exportButton);
          headerContainer.appendChild(filterContianer);
          input.addEventListener('input', main$lambda$lambda_7(select, input, tableBody, index, localization, it));
          select.onchange = main$lambda$lambda_8(input, tableBody, index, select, localization, it);
        }
        var floatButton = Kotlin.isType(tmp$_31 = document.createElement('div'), HTMLDivElement) ? tmp$_31 : throwCCE();
        addClass(floatButton, ['float_button']);
        floatButton.innerHTML = '<a class="btn-floating waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add<\/i><\/a>\n';
        closure$collectionElement.innerHTML = '';
        closure$collectionElement.append(headerContainer, table, floatButton);
        var elems = document.querySelectorAll('select');
        M.FormSelect.init(elems, main$lambda$lambda_9);
        M.updateTextFields();
        setupDropDown(it);
      }
      return Unit;
    };
  }
  function main$lambda$lambda_10(closure$h1iOS, closure$targetProjectLanguage, closure$h1andy) {
    return function (it) {
      if (closure$h1iOS != null) {
        var customJson = generateIosString(it, ensureNotNull(closure$targetProjectLanguage));
        var sequence = splitToSequence(customJson, ['\n']);
        var tmp$;
        tmp$ = sequence.iterator();
        while (tmp$.hasNext()) {
          var element = tmp$.next();
          var closure$h1iOS_0 = closure$h1iOS;
          closure$h1iOS_0.innerHTML = closure$h1iOS_0.innerHTML + (element + '<br>');
        }
      }
      if (closure$h1andy != null) {
        var customJson_0 = generateAndroidString(it, ensureNotNull(closure$targetProjectLanguage));
        var sequence_0 = splitToSequence(htmlEntities(customJson_0), ['\n']);
        var tmp$_0;
        tmp$_0 = sequence_0.iterator();
        while (tmp$_0.hasNext()) {
          var element_0 = tmp$_0.next();
          var closure$h1andy_0 = closure$h1andy;
          closure$h1andy_0.innerHTML = closure$h1andy_0.innerHTML + (element_0 + '<br>');
        }
      }
      return Unit;
    };
  }
  function main$lambda_2(it) {
    var url = new URL(ensureNotNull(document.location).href);
    var targetProjectAlias = url.searchParams.get('alias');
    var targetProjectLanguage = url.searchParams.get('lng');
    if (targetProjectAlias != null) {
      var h1iOS = document.getElementById('iOSH1');
      var h1andy = document.getElementById('andyH1');
      getProject(targetProjectAlias, main$lambda$lambda_10(h1iOS, targetProjectLanguage, h1andy));
    }
    return Unit;
  }
  function main(args) {
    if (contains(window.location.href, 'index.html', false)) {
      window.onload = main$lambda;
    }
     else if (contains(window.location.href, 'project.html')) {
      window.onload = main$lambda_0;
      var url = new URL(ensureNotNull(document.location).href);
      var targetProjectAlias = url.searchParams.get('alias');
      if (targetProjectAlias != null) {
        var collectionElement = document.getElementById('collection-header');
        getProject(targetProjectAlias, main$lambda_1(collectionElement, targetProjectAlias));
      }
    }
     else if (contains(window.location.href, 'localization.html')) {
      window.onload = main$lambda_2;
    }
  }
  function setupModal$lambda(closure$screenNameInput, closure$generatedKeyInput, closure$form, closure$typeInput, closure$keyInput, closure$commentInput, closure$mobileSwitchElem, closure$generateValuesElem, closure$modal) {
    return function () {
      var tmp$;
      if (closure$screenNameInput.value.length > 0) {
        setEditing(false, projectName, closure$screenNameInput.value, closure$generatedKeyInput.value);
      }
      closure$form.reset();
      closure$screenNameInput.disabled = false;
      closure$typeInput.disabled = false;
      closure$keyInput.disabled = false;
      closure$commentInput.disabled = false;
      closure$mobileSwitchElem.disabled = false;
      removeClass(closure$generateValuesElem, ['disabled']);
      var addLocalizationHeading = Kotlin.isType(tmp$ = document.getElementById('add_localization_heading'), HTMLElement) ? tmp$ : throwCCE();
      addLocalizationHeading.innerText = 'Add Localization';
      closure$modal != null ? (closure$modal.removeAttribute('data-mode'), Unit) : null;
    };
  }
  function setupModal$lambda_0() {
    return Unit;
  }
  function setupModal$lambda_1(event) {
    generateKey();
  }
  function setupModal$lambda_2(event) {
    generateKey();
  }
  function setupModal$lambda_3(event) {
    generateKey();
  }
  function setupModal$lambda_4(event) {
    generateKey();
  }
  function setupModal$lambda$lambda(closure$inputElem) {
    return function (it) {
      closure$inputElem.focus();
      closure$inputElem.value = it;
      return Unit;
    };
  }
  function setupModal$lambda_5(closure$keyInput) {
    return function (event) {
      var tmp$, tmp$_0, tmp$_1;
      generateKey();
      var $receiver = closure$keyInput.value;
      var generatedBaseValue = Regex_init('\\d').replace_x2uqeu$($receiver, '');
      if (generatedBaseValue.length === 0)
        return;
      var normalizedValue = capitalize(replace(generatedBaseValue, '_', ' '));
      var elements = document.querySelectorAll('input.validate.language_input');
      tmp$ = asList(elements).iterator();
      while (tmp$.hasNext()) {
        var element = tmp$.next();
        var inputElem = Kotlin.isType(tmp$_0 = element, HTMLInputElement) ? tmp$_0 : throwCCE();
        var langKey = typeof (tmp$_1 = inputElem.getAttribute('data-key')) === 'string' ? tmp$_1 : throwCCE();
        if (equals(langKey, 'en')) {
          inputElem.focus();
          inputElem.value = normalizedValue;
        }
         else {
          YandexHelper$Companion_getInstance().translate_f372nr$(langKey, normalizedValue).then(setupModal$lambda$lambda(inputElem));
        }
      }
    };
  }
  function setupModal$lambda_6(closure$screenNameInput, closure$typeInput, closure$keyInput, closure$commentInput, closure$form, closure$modal) {
    return function (event) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5;
      var screenName = trim(closure$screenNameInput.value, Kotlin.charArrayOf(95));
      var type = trim(closure$typeInput.value, Kotlin.charArrayOf(95));
      var key = trim(closure$keyInput.value, Kotlin.charArrayOf(95));
      var comment = closure$commentInput.value;
      if (!closure$form.checkValidity()) {
        closure$form.reportValidity();
        return;
      }
      var normalizedKey = screenName + '_' + type + '_' + key;
      console.log(normalizedKey);
      var mode = closure$modal != null ? closure$modal.getAttribute('data-mode') : null;
      if (equals(mode, 'editing')) {
        var elements = document.querySelectorAll('input.validate.language_input');
        tmp$ = asList(elements).iterator();
        while (tmp$.hasNext()) {
          var element = tmp$.next();
          var inputElem = Kotlin.isType(tmp$_0 = element, HTMLInputElement) ? tmp$_0 : throwCCE();
          var langKey = typeof (tmp$_1 = inputElem.getAttribute('data-key')) === 'string' ? tmp$_1 : throwCCE();
          var langValue = inputElem.value;
          editLocalization(projectName, screenName, normalizedKey, langKey, langValue);
        }
        var elem = document.getElementById('modal1');
        var modal = M.Modal.getInstance(elem);
        modal.close();
        return;
      }
      var values = json([]);
      var elements_0 = document.querySelectorAll('input.validate.language_input');
      tmp$_2 = asList(elements_0).iterator();
      while (tmp$_2.hasNext()) {
        var element_0 = tmp$_2.next();
        var inputElem_0 = Kotlin.isType(tmp$_3 = element_0, HTMLInputElement) ? tmp$_3 : throwCCE();
        var key_0 = typeof (tmp$_4 = inputElem_0.getAttribute('data-key')) === 'string' ? tmp$_4 : throwCCE();
        var value = inputElem_0.value;
        values[key_0] = value;
      }
      var isMobile = (Kotlin.isType(tmp$_5 = document.getElementById('is_mobile'), HTMLInputElement) ? tmp$_5 : throwCCE()).checked;
      if (addLocalization(projectName, screenName, type, normalizedKey, values, isMobile, comment)) {
        var elem_0 = document.getElementById('modal1');
        var modal_0 = M.Modal.getInstance(elem_0);
        modal_0.close();
      }
    };
  }
  function setupModal() {
    var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6;
    var confirmationModal = document.getElementById('confirm_modal');
    var screenNameInput = Kotlin.isType(tmp$ = document.getElementById('screen_autocomplete_input'), HTMLInputElement) ? tmp$ : throwCCE();
    var typeInput = Kotlin.isType(tmp$_0 = document.getElementById('type_autocomplete_input'), HTMLInputElement) ? tmp$_0 : throwCCE();
    var keyInput = Kotlin.isType(tmp$_1 = document.getElementById('localization_value'), HTMLInputElement) ? tmp$_1 : throwCCE();
    var form = Kotlin.isType(tmp$_2 = document.getElementById('localization_form'), HTMLFormElement) ? tmp$_2 : throwCCE();
    var commentInput = Kotlin.isType(tmp$_3 = document.getElementById('localization_comment'), HTMLInputElement) ? tmp$_3 : throwCCE();
    var modal = document.getElementById('modal1');
    var mobileSwitchElem = Kotlin.isType(tmp$_4 = document.getElementById('is_mobile'), HTMLInputElement) ? tmp$_4 : throwCCE();
    var generateValuesElem = Kotlin.isType(tmp$_5 = document.getElementById('generate_values'), HTMLElement) ? tmp$_5 : throwCCE();
    var generatedKeyInput = Kotlin.isType(tmp$_6 = document.getElementById('disabled'), HTMLInputElement) ? tmp$_6 : throwCCE();
    var params = json([to('onCloseEnd', setupModal$lambda(screenNameInput, generatedKeyInput, form, typeInput, keyInput, commentInput, mobileSwitchElem, generateValuesElem, modal))]);
    M.Modal.init(modal, params);
    M.Modal.init(confirmationModal, setupModal$lambda_0);
    screenNameInput.addEventListener('change', setupModal$lambda_1);
    typeInput.addEventListener('change', setupModal$lambda_2);
    keyInput.addEventListener('change', setupModal$lambda_3);
    mobileSwitchElem.addEventListener('change', setupModal$lambda_4);
    generateValuesElem.addEventListener('click', setupModal$lambda_5(keyInput));
    var addProjectElem = document.getElementById('add_project');
    addProjectElem != null ? (addProjectElem.addEventListener('click', setupModal$lambda_6(screenNameInput, typeInput, keyInput, commentInput, form, modal)), Unit) : null;
  }
  function generateKey() {
    var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3;
    var screenNameInput = Kotlin.isType(tmp$ = document.getElementById('screen_autocomplete_input'), HTMLInputElement) ? tmp$ : throwCCE();
    var typeInput = Kotlin.isType(tmp$_0 = document.getElementById('type_autocomplete_input'), HTMLInputElement) ? tmp$_0 : throwCCE();
    var keyInput = Kotlin.isType(tmp$_1 = document.getElementById('localization_value'), HTMLInputElement) ? tmp$_1 : throwCCE();
    var generatedKeyInput = Kotlin.isType(tmp$_2 = document.getElementById('disabled'), HTMLInputElement) ? tmp$_2 : throwCCE();
    var mobileSwitch = Kotlin.isType(tmp$_3 = document.getElementById('is_mobile'), HTMLInputElement) ? tmp$_3 : throwCCE();
    var screenName = trim(screenNameInput.value, Kotlin.charArrayOf(95));
    var type = trim(typeInput.value, Kotlin.charArrayOf(95));
    var key = trim(keyInput.value, Kotlin.charArrayOf(95));
    var generatedKey = new String_0();
    if (mobileSwitch.checked) {
      generatedKey += 'm_';
    }
    generatedKey += screenName;
    if (!(type.length === 0)) {
      generatedKey += '_' + type;
    }
    if (!(key.length === 0)) {
      generatedKey += '_' + key;
    }
    generatedKeyInput.value = generatedKey;
  }
  function setupCopyElement$lambda(event) {
    var tmp$, tmp$_0;
    var generatedKeyInput = Kotlin.isType(tmp$ = document.getElementById('disabled'), HTMLInputElement) ? tmp$ : throwCCE();
    var clipboardInput = Kotlin.isType(tmp$_0 = document.getElementById('clipboard_input'), HTMLInputElement) ? tmp$_0 : throwCCE();
    clipboardInput.value = generatedKeyInput.value;
    clipboardInput.select();
    document.execCommand('copy');
    M.toast({html: 'Copied', classes: 'rounded'});
  }
  function setupCopyElement() {
    var copyElem = document.getElementById('content_copy');
    copyElem != null ? (copyElem.addEventListener('click', setupCopyElement$lambda), Unit) : null;
  }
  function setupDropDown$lambda(closure$json) {
    return function (event) {
      saveiOS(closure$json);
    };
  }
  function setupDropDown$lambda_0(closure$json) {
    return function (event) {
      saveAndroid(closure$json);
    };
  }
  function setupDropDown$lambda_1(closure$json) {
    return function (event) {
      saveWeb(closure$json);
    };
  }
  function setupDropDown(json) {
    var elems = document.querySelectorAll('.dropdown-trigger');
    var instances = M.Dropdown.init(elems, {});
    var exportiOSElement = document.getElementById('export_ios');
    var exportAndroidElement = document.getElementById('export_android');
    var exportWebElement = document.getElementById('export_web');
    exportiOSElement != null ? (exportiOSElement.addEventListener('click', setupDropDown$lambda(json)), Unit) : null;
    exportAndroidElement != null ? (exportAndroidElement.addEventListener('click', setupDropDown$lambda_0(json)), Unit) : null;
    exportWebElement != null ? (exportWebElement.addEventListener('click', setupDropDown$lambda_1(json)), Unit) : null;
  }
  function tableRowDataFromScreen$lambda$lambda(closure$values) {
    return function (value) {
      closure$values.put_xwzc9p$(value['lang_key'].toString(), value['lang_value'].toString());
    };
  }
  function tableRowDataFromScreen$lambda(closure$array, closure$name) {
    return function (localization) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3;
      var key = typeof (tmp$ = localization['key']) === 'string' ? tmp$ : throwCCE();
      var comment = typeof (tmp$_0 = localization['comment']) === 'string' ? tmp$_0 : null;
      var isMobile = typeof (tmp$_1 = localization['isMobile']) === 'boolean' ? tmp$_1 : throwCCE();
      var values = LinkedHashMap_init();
      Object_0().values(localization['values']).forEach(tableRowDataFromScreen$lambda$lambda(values));
      tmp$_3 = typeof (tmp$_2 = localization.isEditing) === 'boolean' ? tmp$_2 : throwCCE();
      closure$array.add_11rb$(TableRowData_init(closure$name, key, comment, isMobile, values, tmp$_3));
    };
  }
  function tableRowDataFromScreen(name, screen) {
    var array = ArrayList_init();
    if (screen != null) {
      Object_0().values(screen).forEach(tableRowDataFromScreen$lambda(array, name));
    }
    return copyToArray(array);
  }
  function tableRowElementFromTableRowData$lambda$lambda(closure$tableRowData) {
    return function (e) {
      console.log(projectName, closure$tableRowData.screen, closure$tableRowData.key);
      removeRow(projectName, closure$tableRowData.screen, closure$tableRowData.key);
    };
  }
  function tableRowElementFromTableRowData$lambda(closure$tableRowData) {
    return function (event) {
      var modal = document.getElementById('confirm_modal');
      var instance = M.Modal.getInstance(modal);
      instance.open();
      var delete_0 = document.getElementById('confirm_modal_delete');
      delete_0 != null ? (delete_0.addEventListener('click', tableRowElementFromTableRowData$lambda$lambda(closure$tableRowData)), Unit) : null;
      console.log('delete');
    };
  }
  function tableRowElementFromTableRowData$lambda_0(closure$editElem) {
    return function (f) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6, tmp$_7, tmp$_8, tmp$_9, tmp$_10, tmp$_11, tmp$_12, tmp$_13, tmp$_14, tmp$_15, tmp$_16, tmp$_17, tmp$_18, tmp$_19, tmp$_20, tmp$_21;
      console.log('edit');
      var screenNameInput = Kotlin.isType(tmp$ = document.getElementById('screen_autocomplete_input'), HTMLInputElement) ? tmp$ : throwCCE();
      var typeInput = Kotlin.isType(tmp$_0 = document.getElementById('type_autocomplete_input'), HTMLInputElement) ? tmp$_0 : throwCCE();
      var keyInput = Kotlin.isType(tmp$_1 = document.getElementById('localization_value'), HTMLInputElement) ? tmp$_1 : throwCCE();
      var generatedKeyInput = Kotlin.isType(tmp$_2 = document.getElementById('disabled'), HTMLInputElement) ? tmp$_2 : throwCCE();
      var commentInput = Kotlin.isType(tmp$_3 = document.getElementById('localization_comment'), HTMLInputElement) ? tmp$_3 : throwCCE();
      var languageElements = document.querySelectorAll('input.validate.language_input');
      var mobileSwitchElem = Kotlin.isType(tmp$_4 = document.getElementById('is_mobile'), HTMLInputElement) ? tmp$_4 : throwCCE();
      var generateValuesElem = Kotlin.isType(tmp$_5 = document.getElementById('generate_values'), HTMLElement) ? tmp$_5 : throwCCE();
      var addLocalizationHeading = Kotlin.isType(tmp$_6 = document.getElementById('add_localization_heading'), HTMLElement) ? tmp$_6 : throwCCE();
      addLocalizationHeading.innerText = 'Edit Localization';
      var trElement = Kotlin.isType(tmp$_8 = (tmp$_7 = closure$editElem.parentElement) != null ? tmp$_7.parentElement : null, HTMLTableRowElement) ? tmp$_8 : throwCCE();
      var screenName = typeof (tmp$_10 = (tmp$_9 = trElement.children[1]) != null ? tmp$_9.innerHTML : null) === 'string' ? tmp$_10 : throwCCE();
      var key = typeof (tmp$_12 = (tmp$_11 = trElement.children[2]) != null ? tmp$_11.innerHTML : null) === 'string' ? tmp$_12 : throwCCE();
      var comment = typeof (tmp$_14 = (tmp$_13 = trElement.children[3]) != null ? tmp$_13.innerHTML : null) === 'string' ? tmp$_14 : null;
      var indexElem = trElement.children[0];
      console.log(indexElem);
      var mobileAttribute = typeof (tmp$_15 = indexElem != null ? indexElem.getAttribute('mobile') : null) === 'string' ? tmp$_15 : throwCCE();
      var isMobile = equals(mobileAttribute, 'true');
      screenNameInput.value = screenName;
      var normalizedKey = replaceFirst(key, '_m', '');
      keyInput.value = substringAfterLast(normalizedKey, '_');
      typeInput.value = substringBeforeLast(substringAfter(normalizedKey, '_'), '_');
      generatedKeyInput.value = key;
      commentInput.value = comment != null ? comment : '';
      mobileSwitchElem.checked = isMobile;
      var element;
      var value;
      tmp$_16 = trElement.childElementCount - 2 | 0;
      for (var i = 4; i <= tmp$_16; i++) {
        var element_0 = Kotlin.isType(tmp$_17 = languageElements[i - 4 | 0], HTMLInputElement) ? tmp$_17 : throwCCE();
        var value_0 = typeof (tmp$_19 = (tmp$_18 = trElement.children[i]) != null ? tmp$_18.innerHTML : null) === 'string' ? tmp$_19 : throwCCE();
        element_0.value = value_0;
      }
      var modal = document.getElementById('modal1');
      modal != null ? (modal.setAttribute('data-mode', 'editing'), Unit) : null;
      var instance = M.Modal.getInstance(modal);
      instance.open();
      screenNameInput.select();
      typeInput.select();
      keyInput.select();
      commentInput.select();
      screenNameInput.className = '';
      typeInput.className = '';
      keyInput.className = '';
      screenNameInput.disabled = true;
      typeInput.disabled = true;
      keyInput.disabled = true;
      commentInput.disabled = true;
      mobileSwitchElem.disabled = true;
      addClass(generateValuesElem, ['disabled']);
      tmp$_20 = asList(languageElements).iterator();
      while (tmp$_20.hasNext()) {
        var elem = tmp$_20.next();
        (Kotlin.isType(tmp$_21 = elem, HTMLInputElement) ? tmp$_21 : throwCCE()).focus();
      }
      setEditing(true, projectName, screenName, key);
    };
  }
  function tableRowElementFromTableRowData(tableRowData, index) {
    var tmp$, tmp$_0, tmp$_1, tmp$_2;
    var tr = Kotlin.isType(tmp$ = document.createElement('tr'), HTMLTableRowElement) ? tmp$ : throwCCE();
    var tableIndex = document.createElement('td');
    addClass(tableIndex, ['table_index']);
    tableIndex.innerHTML = index.toString();
    tableIndex.setAttribute('mobile', tableRowData.isMobile ? 'true' : 'false');
    var tableScreen = document.createElement('td');
    addClass(tableScreen, ['table_screen']);
    tableScreen.innerHTML = tableRowData.screen;
    var tableKey = document.createElement('td');
    tableKey.innerHTML = tableRowData.key;
    var tableComment = Kotlin.isType(tmp$_0 = document.createElement('td'), HTMLElement) ? tmp$_0 : throwCCE();
    var $receiver = tableRowData.comment;
    tableComment.innerHTML = $receiver != null ? $receiver : '';
    tableComment.hidden = true;
    tr.append(tableIndex, tableScreen, tableKey, tableComment);
    var tmp$_3;
    tmp$_3 = tableRowData.values.entries.iterator();
    while (tmp$_3.hasNext()) {
      var element = tmp$_3.next();
      var languageValue = element.value;
      var td = document.createElement('td');
      td.innerHTML = languageValue;
      tr.appendChild(td);
    }
    var tdOptions = document.createElement('td');
    addClass(tdOptions, ['head_options']);
    var deleteElem = Kotlin.isType(tmp$_1 = document.createElement('i'), HTMLElement) ? tmp$_1 : throwCCE();
    addClass(deleteElem, ['small']);
    addClass(deleteElem, ['material-icons']);
    addClass(deleteElem, ['action']);
    deleteElem.innerText = 'delete';
    deleteElem.hidden = tableRowData.isEditing;
    deleteElem.addEventListener('click', tableRowElementFromTableRowData$lambda(tableRowData));
    var editElem = Kotlin.isType(tmp$_2 = document.createElement('i'), HTMLElement) ? tmp$_2 : throwCCE();
    addClass(editElem, ['small']);
    addClass(editElem, ['material-icons']);
    addClass(editElem, ['action']);
    editElem.innerText = 'edit';
    editElem.hidden = tableRowData.isEditing;
    editElem.addEventListener('click', tableRowElementFromTableRowData$lambda_0(editElem));
    tdOptions.append(deleteElem, editElem);
    tr.appendChild(tdOptions);
    tr.className = tableRowData.isEditing ? 'background_yellow' : '';
    return tr;
  }
  function addLanguageInputsToPopup$lambda(closure$innerHtml) {
    return function (language) {
      var tmp$, tmp$_0;
      var languageName = typeof (tmp$ = language['langName']) === 'string' ? tmp$ : throwCCE();
      var languageCode = typeof (tmp$_0 = language['langCode']) === 'string' ? tmp$_0 : throwCCE();
      closure$innerHtml.v += '' + '<div class="row">' + '   <div class="input-field col s12">\n' + '       <i class="material-icons prefix value">g_translate<\/i>\n' + ('       <input id=' + '"' + 'language_input_' + languageCode + '"' + ' data-key=' + '"' + languageCode + '"' + ' type=' + '"' + 'text' + '"' + ' autocomplete=' + '"' + 'off' + '"' + ' class=' + '"' + 'validate language_input' + '"' + ' pattern=' + '"' + '.{1,}' + '"' + ' required title=' + '"' + '"' + '>') + ('       <label for=' + '"' + 'language_input_' + languageCode + '"' + '>' + languageName + '<\/label>') + '   <\/div>' + '<\/div>';
    };
  }
  function addLanguageInputsToPopup$lambda$lambda$lambda$lambda(closure$languageInputElement) {
    return function (it) {
      closure$languageInputElement.focus();
      closure$languageInputElement.value = it;
      return Unit;
    };
  }
  function addLanguageInputsToPopup$lambda$lambda(closure$it) {
    return function (event) {
      var tmp$, tmp$_0, tmp$_1;
      var parentElement = Kotlin.isType(tmp$ = closure$it.parentElement, HTMLDivElement) ? tmp$ : throwCCE();
      var inputElement = Kotlin.isType(tmp$_0 = parentElement.children[1], HTMLInputElement) ? tmp$_0 : throwCCE();
      var from = inputElement.value;
      if (from.length === 0) {
        alert('Please type value');
        return;
      }
      var langKey = typeof (tmp$_1 = inputElement.getAttribute('data-key')) === 'string' ? tmp$_1 : throwCCE();
      var inputElems = document.querySelectorAll('input.validate.language_input');
      var tmp$_2;
      tmp$_2 = asList(inputElems).iterator();
      while (tmp$_2.hasNext()) {
        var element = tmp$_2.next();
        var tmp$_3, tmp$_4;
        var languageInputElement = Kotlin.isType(tmp$_3 = element, HTMLInputElement) ? tmp$_3 : throwCCE();
        var _langKey = typeof (tmp$_4 = languageInputElement.getAttribute('data-key')) === 'string' ? tmp$_4 : throwCCE();
        if (!equals(langKey, _langKey)) {
          console.log(langKey, '-', _langKey);
          YandexHelper$Companion_getInstance().translate_f372nr$(_langKey, from).then(addLanguageInputsToPopup$lambda$lambda$lambda$lambda(languageInputElement));
        }
      }
    };
  }
  function addLanguageInputsToPopup(json) {
    var tmp$;
    var elems = document.querySelectorAll('i.material-icons.prefix.value');
    if (elems.length > 0) {
      return;
    }
    var element = document.getElementById('localization_input');
    if (element != null) {
      var innerHtml = {v: ''};
      var languagesJson = Kotlin.isType(tmp$ = json['languages'], Object) ? tmp$ : throwCCE();
      Object.values(languagesJson).forEach(addLanguageInputsToPopup$lambda(innerHtml));
      element.innerHTML = innerHtml.v;
      var elems_0 = document.querySelectorAll('i.material-icons.prefix.value');
      var tmp$_0;
      tmp$_0 = asList(elems_0).iterator();
      while (tmp$_0.hasNext()) {
        var element_0 = tmp$_0.next();
        element_0.addEventListener('click', addLanguageInputsToPopup$lambda$lambda(element_0));
      }
    }
  }
  function setupLanguageOptions$lambda$lambda() {
    return Unit;
  }
  function setupLanguageOptions$lambda(it) {
    var tmp$, tmp$_0, tmp$_1;
    var select = Kotlin.isType(tmp$ = document.createElement('select'), HTMLSelectElement) ? tmp$ : throwCCE();
    select.id = 'language_select';
    select.multiple = true;
    var index = indexOf_0(it.keys, 'en');
    var tmp$_2;
    tmp$_2 = it.entries.iterator();
    while (tmp$_2.hasNext()) {
      var element = tmp$_2.next();
      var tmp$_3;
      var option = Kotlin.isType(tmp$_3 = document.createElement('option'), HTMLOptionElement) ? tmp$_3 : throwCCE();
      option.value = element.key;
      option.text = element.value;
      select.appendChild(option);
    }
    var enOption = Kotlin.isType(tmp$_0 = select.options[index], HTMLOptionElement) ? tmp$_0 : throwCCE();
    enOption.selected = true;
    enOption.disabled = true;
    var div = Kotlin.isType(tmp$_1 = document.getElementById('languages-combobox'), HTMLDivElement) ? tmp$_1 : throwCCE();
    div.insertBefore(select, div.firstChild);
    var elems = document.querySelectorAll('select');
    M.FormSelect.init(elems, setupLanguageOptions$lambda$lambda);
    setupAddProjectButton(select);
    return Unit;
  }
  function setupLanguageOptions() {
    YandexHelper$Companion_getInstance().supportedLanguages_61zpoe$().then(setupLanguageOptions$lambda);
  }
  function setupAddProjectButton$lambda(closure$select) {
    return function (it) {
      var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3;
      var modalElem = document.getElementById('modal1');
      var mode = modalElem != null ? modalElem.getAttribute('mode') : null;
      var createProjectForm = Kotlin.isType(tmp$ = document.getElementById('create_project_form'), HTMLFormElement) ? tmp$ : throwCCE();
      if (!createProjectForm.checkValidity()) {
        createProjectForm.reportValidity();
        return;
      }
      var projectName = (Kotlin.isType(tmp$_0 = document.getElementById('project_name'), HTMLInputElement) ? tmp$_0 : throwCCE()).value;
      var projectAlias = (Kotlin.isType(tmp$_1 = document.getElementById('project_alias'), HTMLInputElement) ? tmp$_1 : throwCCE()).value;
      var languages = ArrayList_init();
      tmp$_2 = closure$select.selectedOptions.length - 1 | 0;
      for (var i = 0; i <= tmp$_2; i++) {
        var option = Kotlin.isType(tmp$_3 = closure$select.selectedOptions[i], HTMLOptionElement) ? tmp$_3 : throwCCE();
        languages.add_11rb$(to(option.value, option.text));
      }
      if (equals(mode, 'editing')) {
        addLanguages(projectName, copyToArray(languages));
      }
       else {
        createProject(projectName, projectAlias, copyToArray(languages));
      }
      var modal = M.Modal.getInstance(modalElem);
      modal.close();
      return Unit;
    };
  }
  function setupAddProjectButton(select) {
    var addButton = document.getElementById('add_project');
    addButton != null ? (addButton.addEventListener('click', setupAddProjectButton$lambda(select)), Unit) : null;
  }
  function TableRowData() {
    this.screen = '';
    this.key = '';
    this.values = LinkedHashMap_init();
    this.comment = null;
    this.isMobile = false;
    this.isEditing = false;
  }
  TableRowData.prototype.toString = function () {
    return 'screen = ' + this.screen + ', key = ' + this.key + ', comment = ' + toString(this.comment) + ', values = ' + this.values.toString();
  };
  TableRowData.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'TableRowData',
    interfaces: []
  };
  function TableRowData_init(screen, key, comment, isMobile, values, isEditing, $this) {
    $this = $this || Object.create(TableRowData.prototype);
    TableRowData.call($this);
    $this.screen = screen;
    $this.key = key;
    $this.comment = comment;
    $this.isMobile = isMobile;
    $this.values = values;
    $this.isEditing = isEditing;
    return $this;
  }
  function loadJSON$lambda(closure$json, closure$map) {
    return function (key) {
      var tmp$;
      var $receiver = closure$map;
      var value = typeof (tmp$ = closure$json[key]) === 'string' ? tmp$ : throwCCE();
      $receiver.put_xwzc9p$(key, value);
    };
  }
  var HashMap_init = Kotlin.kotlin.collections.HashMap_init_q3lmfv$;
  function loadJSON(callBack) {
    var json = langs;
    var map = HashMap_init();
    Object.keys(json).forEach(loadJSON$lambda(json, map));
    callBack(map);
  }
  _.createProject_cufykj$ = createProject;
  _.addScreens_60y5e1$ = addScreens;
  _.addTypes_60y5e1$ = addTypes;
  _.getProjects_jqcwca$ = getProjects;
  _.getProject_3ocb49$ = getProject;
  _.addLanguages_3zou0b$ = addLanguages;
  _.filterScreens_y0gzxh$ = filterScreens;
  _.setEditing_h2udbj$ = setEditing;
  _.addStrings_8m11s9$ = addStrings;
  _.removeValueFromChildArray_6hosri$ = removeValueFromChildArray;
  _.removeLocalizaton_w74nik$ = removeLocalizaton;
  _.removeRow_6hosri$ = removeRow;
  _.editLocalization_x0a6t6$ = editLocalization;
  _.deleteProject_dhjwdb$ = deleteProject;
  _.existKeyInProject = existKeyInProject;
  _.createJson = createJson;
  Object.defineProperty(YandexHelper, 'Companion', {
    get: YandexHelper$Companion_getInstance
  });
  _.YandexHelper = YandexHelper;
  _.Object = Object_0;
  Object.defineProperty(Constants$FIREBASE$contentType, 'Companion', {
    get: Constants$FIREBASE$contentType$Companion_getInstance
  });
  Constants$FIREBASE.contentType = Constants$FIREBASE$contentType;
  Constants.FIREBASE = Constants$FIREBASE;
  Object.defineProperty(Constants$YANDEX, 'Companion', {
    get: Constants$YANDEX$Companion_getInstance
  });
  Constants.YANDEX = Constants$YANDEX;
  _.Constants = Constants;
  Object.defineProperty(_, 'firebase', {
    get: function () {
      return firebase_0;
    },
    set: function (value) {
      firebase_0 = value;
    }
  });
  Object.defineProperty(_, 'dbRef', {
    get: function () {
      return dbRef;
    },
    set: function (value) {
      dbRef = value;
    }
  });
  Object.defineProperty(_, 'projectName', {
    get: function () {
      return projectName;
    },
    set: function (value) {
      projectName = value;
    }
  });
  _.main_kand9s$ = main;
  _.tableRowDataFromScreen_qlbjqp$ = tableRowDataFromScreen;
  _.tableRowElementFromTableRowData_nefdfc$ = tableRowElementFromTableRowData;
  _.addLanguageInputsToPopup_qk3xy8$ = addLanguageInputsToPopup;
  _.setupLanguageOptions = setupLanguageOptions;
  _.setupAddProjectButton_3xckbc$ = setupAddProjectButton;
  _.TableRowData_init_ec5z5j$ = TableRowData_init;
  _.TableRowData = TableRowData;
  _.loadJSON_396llb$ = loadJSON;
  firebase_0 = firebase;
  dbRef = firebase_0.database().ref().child('projects');
  projectName = new String_0();
  main([]);
  Kotlin.defineModule('app', _);
  return _;
}(typeof app === 'undefined' ? {} : app, kotlin);

//# sourceMappingURL=app.js.map
